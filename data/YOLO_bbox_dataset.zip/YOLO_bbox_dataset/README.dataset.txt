# STICKERS > 2025-04-30 10:22am
https://universe.roboflow.com/horseshoe/stickers-q9fwk

Provided by a Roboflow user
License: CC BY 4.0

