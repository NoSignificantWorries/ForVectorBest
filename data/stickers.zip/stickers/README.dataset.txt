# stickers > 2025-03-09 2:02pm
https://universe.roboflow.com/horseshoe/stickers-9eu1e

Provided by a Roboflow user
License: CC BY 4.0

